***** TACOS Server Export *****
Mit Hilfe des serverExport.jardesc Files muss das at.rc.tacos.server File aus Eclipse heraus (rechte Maus und create Jar)
exportiert und hier in diesem Ordner abgespeichert werden (auf gleicher Ebene wie das ReadMe- File).

Vor dem Export muss das File db.properties entsprechend angepasst werden.

Der Server kann dann �ber start.bat gestartet werden.